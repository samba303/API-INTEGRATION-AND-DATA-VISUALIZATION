# API-INTEGRATION-AND-DATA-VISUALIZATION
Use PYTHON to fetch the data from a public API and create visualization using matplotlib or seaborn.
